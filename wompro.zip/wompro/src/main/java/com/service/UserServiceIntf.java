package com.service;


import java.util.List;

import com.model.Hostel;
import com.model.Ngotable;
import com.model.Sukanya;
import com.model.Training;
import com.model.Users;
import com.model.Workingwomen;

public interface UserServiceIntf 
{
	public boolean insertUser(Users user);
	public Users userLogin(Users user);
	public boolean changePassword(String username,String opwd, String npwd);
	public void enterPassword(String email_id,String contact_number, String password);
	public boolean insertWorkingwomen(Workingwomen ww);
	public List<Workingwomen> getUsers();
	public boolean insertForm( Sukanya sukanya);
	public List<Sukanya> getUser();
	public boolean insertngo(Ngotable ngo);
	public List<Ngotable> getNgo();
	public boolean inserttraining(Training training);
	public List<Training> getTraining();
	public boolean insertForm( Hostel hostel);
	public List<Hostel> getUserh();
}
