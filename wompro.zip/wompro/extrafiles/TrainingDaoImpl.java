/*package com.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.springframework.stereotype.Repository;

import com.model.Training;

@Repository("trainingDao")
public class TrainingDaoImpl implements TrainingDaoIntf{

	public boolean inserttraining(Training training) {
		boolean result=false;
		
		try{
			EntityManagerFactory emf=Persistence.createEntityManagerFactory("pu");
			EntityManager em=emf.createEntityManager();
			em.getTransaction().begin();
			em.persist(training);
			em.getTransaction().commit();
			System.out.println("dao training is called");
            result=true;
            em.close();
            emf.close();
			
		}
		catch(Exception ee){
			System.out.println(ee.getMessage());
		}
		
		return result;
	}

	public List<Training> gettraining() {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("pu");
		EntityManager em=emf.createEntityManager();
		@SuppressWarnings("unchecked")
		List<Training> list=em.createQuery("SELECT t FROM Training t").getResultList();
		System.out.println("dao is called");
		return list;
	}

}
*/