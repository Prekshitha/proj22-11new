/*package com.dao;

import java.util.List;

import com.model.Training;

public interface TrainingDaoIntf {

	boolean inserttraining(Training training);

	public List<Training> gettraining();

}
*/