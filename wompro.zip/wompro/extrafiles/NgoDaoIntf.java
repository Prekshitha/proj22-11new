/*package com.dao;

import java.util.List;

import com.model.Ngotable;

public interface NgoDaoIntf {
	boolean insertngo(Ngotable ngo);

	public List<Ngotable> getNgo();


}
*/