/*package com.service;

import java.util.List;

import com.controller.HostelController;
import com.model.Hostel;



public interface HostelServiceIntf {
	public boolean insertForm( Hostel hostel);
	public List<Hostel> getUserh();
}
*/