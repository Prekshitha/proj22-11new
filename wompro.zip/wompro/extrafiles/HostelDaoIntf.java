/*package com.dao;

import java.util.List;

import com.model.Hostel;



public interface HostelDaoIntf {
	public boolean insertForm(Hostel hostel);
	public List<Hostel> getUserh();
}
*/