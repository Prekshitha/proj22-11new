/*package com.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.springframework.stereotype.Repository;

import com.model.Sukanya;

@Repository("SDao")
public class SukanyaDaoImpl implements SukanyaDaoIntf {
		public boolean insertForm(Sukanya sukanya) {
			System.out.println("dao called");
			boolean flag=false;
			try{
				EntityManagerFactory emf=Persistence.createEntityManagerFactory("pu");
				EntityManager em=emf.createEntityManager();
				em.getTransaction().begin();
				em.persist(sukanya);
				em.getTransaction().commit();
			    em.close();
			    emf.close();
			    flag=true;
			    System.out.println("Done");
				}
				catch (Exception e){
					System.out.println("Error"+e);
				}
			
			return flag;
		}
		public List<Sukanya> getUser() {
			EntityManagerFactory emf=Persistence.createEntityManagerFactory("pu");
			EntityManager em=emf.createEntityManager();
			@SuppressWarnings("unchecked")
			List<Sukanya> list= em.createQuery("SELECT u FROM  Sukanya u").getResultList();
			System.out.println("dao is called:"+ list.size());
			return list;
		}
}


*/