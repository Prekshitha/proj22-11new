/*package com.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.springframework.stereotype.Repository;

import com.controller.HostelController;
import com.model.Hostel;


@Repository("HDao")
public class HostelDaoImpl implements HostelDaoIntf {
	

			public boolean insertForm(Hostel hostel) {

				boolean flag=false;
				try{
					EntityManagerFactory emf=Persistence.createEntityManagerFactory("pu");
					EntityManager em=emf.createEntityManager();
					em.getTransaction().begin();
					em.persist(hostel);
					em.getTransaction().commit();
				    em.close();
				    emf.close();
				    flag=true;
				    System.out.println("dao called");
				    System.out.println("Done");
					}
					catch (Exception e){
						System.out.println("Error"+e);
					}
				
				return flag;
			}
			public List<Hostel> getUserh() {
				EntityManagerFactory emf=Persistence.createEntityManagerFactory("pu");
				EntityManager em=emf.createEntityManager();
				@SuppressWarnings("unchecked")
				List<Hostel> list= em.createQuery("SELECT u FROM  Hostel u").getResultList();
				System.out.println("dao is called:"+ list.size());
				return list;
			}
}
*/